<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Class\\App\\Providers\\ClassServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Class\\App\\Providers\\ClassServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);