<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BuildingType\\App\\Providers\\BuildingTypeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BuildingType\\App\\Providers\\BuildingTypeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);