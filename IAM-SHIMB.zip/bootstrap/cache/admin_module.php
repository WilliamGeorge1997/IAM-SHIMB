<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admin\\App\\Providers\\AdminServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admin\\App\\Providers\\AdminServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);