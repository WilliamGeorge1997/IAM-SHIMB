<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Trainer\\App\\Providers\\TrainerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Trainer\\App\\Providers\\TrainerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);