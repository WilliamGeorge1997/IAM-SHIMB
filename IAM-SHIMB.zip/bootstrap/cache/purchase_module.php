<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Purchase\\App\\Providers\\PurchaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Purchase\\App\\Providers\\PurchaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);