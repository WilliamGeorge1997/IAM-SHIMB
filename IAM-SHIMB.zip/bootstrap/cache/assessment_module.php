<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Assessment\\App\\Providers\\AssessmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Assessment\\App\\Providers\\AssessmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);