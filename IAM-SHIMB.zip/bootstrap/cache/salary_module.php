<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Salary\\App\\Providers\\SalaryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Salary\\App\\Providers\\SalaryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);