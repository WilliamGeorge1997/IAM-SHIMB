<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Build\\App\\Providers\\BuildServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Build\\App\\Providers\\BuildServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);