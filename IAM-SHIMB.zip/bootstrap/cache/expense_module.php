<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Expense\\App\\Providers\\ExpenseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Expense\\App\\Providers\\ExpenseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);