<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Country\\App\\Providers\\CountryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Country\\App\\Providers\\CountryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);