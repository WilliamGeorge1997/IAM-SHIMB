<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php /**PATH E:\Programming\Mohamed Shafik\IAM-SHIMB\Modules/Common\resources/views/includes/css.blade.php ENDPATH**/ ?>