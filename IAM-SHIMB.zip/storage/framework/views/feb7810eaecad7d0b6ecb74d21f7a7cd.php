<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php /**PATH E:\Programming\Mohamed Shafik\IAM-SHIMB\Modules/Common\resources/views/includes/js.blade.php ENDPATH**/ ?>