<?php $__env->startSection('css'); ?>
    <style>
        .percentage-badge {
            font-weight: 600;
            font-size: 0.75rem;
            padding: 0.2rem 0.5rem;
            border-radius: 0.375rem;
            display: inline-block;
            margin: 0.1rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-2">
        <!-- Dashboard Header -->
        <div class="bg-gradient-primary text-white rounded-3 p-2 mb-2 shadow"
            style="background: linear-gradient(135deg, #1976d2 0%, #64b5f6 100%);">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center">
                <div>
                    <h1 class="h6 fw-semibold mb-0">
                        <i class="bi bi-building me-1" style="font-size: 0.9rem;"></i>
                        Select Building Type
                    </h1>
                    <p class="mb-0 opacity-75" style="font-size: 0.75rem;">Choose a building type to continue.</p>
                </div>
                <div class="mt-2 mt-md-0 d-flex gap-2">
                    <a href="<?php echo e(route('index')); ?>"
                        class="btn btn-light btn-sm rounded-pill d-flex align-items-center"
                        style="font-size: 0.8rem; padding: 0.25rem 0.75rem;">
                        <i class="bi bi-house-door me-1"></i>
                        Home
                    </a>
                    <a href="<?php echo e(route('mega-buildings.index')); ?>"
                        class="btn btn-light btn-sm rounded-pill d-flex align-items-center"
                        style="font-size: 0.8rem; padding: 0.25rem 0.75rem;">
                        <i class="bi bi-arrow-left me-1"></i>
                        Back to Mega Buildings
                    </a>
                </div>
            </div>
        </div>
        <!-- Context Information Bar -->
        <div class="mb-2">
            <div
                class="d-flex flex-column flex-md-row align-items-md-center gap-2 p-2 bg-white rounded-2 shadow-sm border border-light">
                <a href="<?php echo e(route('mega-buildings.index')); ?>" class="text-decoration-none context-item-hover">
                    <div class="d-flex align-items-center gap-2">
                        <div class="bg-primary bg-opacity-10 rounded-circle p-1">
                            <i class="bi bi-building text-primary" style="font-size: 0.85rem;"></i>
                        </div>
                        <div>
                            <div class="text-muted fw-semibold text-uppercase"
                                style="font-size: 0.65rem; letter-spacing: 0.5px;">Mega Building</div>
                            <div class="fw-bold text-dark" style="font-size: 0.85rem;"><?php echo e($megaBuilding->name); ?></div>
                        </div>

                    </div>
                </a>
            </div>
        </div>

        <!-- Building Types Section -->
        <div class="card shadow rounded-3 border-0 mb-2 py-2 px-2">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show my-2" role="alert">
                    <i class="bi bi-check-circle me-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="card-header bg-transparent border-0 pb-0">
                <h2 class="h6 mb-0 fw-semibold d-flex align-items-center">
                    <i class="bi bi-list-check text-primary me-1" style="font-size: 0.9rem;"></i>
                    Available Building Types
                </h2>
            </div>
            <div class="card-body p-0 container my-2">
                <?php if($buildingTypes->isNotEmpty()): ?>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0 table-borderless table-hover" style="font-size: 0.875rem;">
                            <thead class="table-light">
                                <tr>
                                    <th class="fw-semibold text-secondary" style="font-size: 0.8rem;">No.</th>
                                    <th class="fw-semibold text-secondary" style="font-size: 0.8rem;">Building Type</th>
                                    <th class="fw-semibold text-secondary" style="font-size: 0.8rem;">Percentages</th>
                                    <th class="fw-semibold text-end text-secondary" style="font-size: 0.8rem;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $buildingTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buildingType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $percentages = $buildingTypePercentages[$buildingType->id] ?? [];
                                    ?>
                                    <tr class="border-bottom"
                                        onclick="window.location.href='<?php echo e(route('assessment-groups.index', ['mega_building' => $megaBuilding->id, 'building_type' => $buildingType->id])); ?>'"
                                        style="cursor: pointer;" onmouseover="this.style.backgroundColor='#f8f9fa'"
                                        onmouseout="this.style.backgroundColor='transparent'">
                                        <td>
                                            <span class="fw-semibold"
                                                style="font-size: 0.85rem;"><?php echo e($loop->iteration); ?></span>
                                        </td>
                                        <td>
                                            <span class="fw-semibold"
                                                style="font-size: 0.85rem;"><?php echo e($buildingType->name); ?></span>
                                        </td>
                                        <td>
                                            <?php if(!empty($percentages)): ?>
                                                <div class="d-flex flex-wrap gap-1 align-items-center">
                                                    <?php if(isset($percentages['Sustainable'])): ?>
                                                        <span class="percentage-badge classification-sustainable">
                                                            Sustainable: <?php echo e($percentages['Sustainable']); ?>%
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if(isset($percentages['Healthy'])): ?>
                                                        <span class="percentage-badge classification-healthy">
                                                            Healthy: <?php echo e($percentages['Healthy']); ?>%
                                                        </span>
                                                    <?php endif; ?>
                                                    <?php if(isset($percentages['Intelligent'])): ?>
                                                        <span class="percentage-badge classification-intelligent">
                                                            Intelligent: <?php echo e($percentages['Intelligent']); ?>%
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted" style="font-size: 0.8rem;">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <span
                                                class="btn btn-primary btn-sm rounded-pill px-3 d-inline-flex align-items-center gap-1"
                                                style="font-size: 0.8rem; padding: 0.2rem 0.6rem;">
                                                <i class="bi bi-check-circle" style="font-size: 0.85rem;"></i>
                                                Select
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-3">
                        <i class="bi bi-building-x text-muted opacity-50 mb-2" style="font-size: 2.5rem;"></i>
                        <h5 class="fw-semibold mb-1" style="font-size: 1rem;">No Building Types Available</h5>
                        <p class="text-muted mb-2" style="font-size: 0.85rem;">Please contact administrator to add building
                            types.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const alertSuccess = document.querySelector('.alert-success');
            if (alertSuccess) {
                setTimeout(() => {
                    alertSuccess.classList.add('fade');
                    setTimeout(() => {
                        alertSuccess.remove();
                    }, 500);
                }, 3000);
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common::layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programming\Mohamed Shafik\IAM-SHIMB\Modules/Build\resources/views/building-types/index.blade.php ENDPATH**/ ?>