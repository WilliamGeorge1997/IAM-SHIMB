<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Mega Building Assessment - <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo.webp')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-icons.min.css')); ?>">

    <style>
        body {
            background-color: rgb(230, 230, 230);
        }

        .classification-sustainable {
            color: #1976d2 !important;
        }

        .classification-intelligent {
            color: #ff9800 !important;
        }

        .classification-healthy {
            color: #4caf50 !important;
        }

        .percentage-badge {
            font-weight: 600;
            font-size: 0.75rem;
            padding: 0.2rem 0.5rem;
            border-radius: 0.375rem;
            display: inline-block;
            margin: 0.1rem;
        }

        .context-item-hover {
            transition: background 0.2s;
            border-radius: 0.4rem;
            display: inline-block;
        }

        .context-item-hover:hover {
            background-color: rgba(108, 117, 125, 0.1) !important;
            text-decoration: none;
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('assets/js/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/justgage.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>
<?php /**PATH E:\Programming\Mohamed Shafik\IAM-SHIMB\Modules/Common\resources/views/layouts/dashboard/master.blade.php ENDPATH**/ ?>