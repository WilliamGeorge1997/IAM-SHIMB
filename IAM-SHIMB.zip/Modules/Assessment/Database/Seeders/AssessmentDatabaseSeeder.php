<?php

namespace Modules\Assessment\Database\Seeders;

use Illuminate\Database\Seeder;

class AssessmentDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
