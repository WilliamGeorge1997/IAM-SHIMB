<?php

return [
    'name' => 'Assessment',
];
