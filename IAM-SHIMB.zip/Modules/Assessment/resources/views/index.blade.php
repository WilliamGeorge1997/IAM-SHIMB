@extends('assessment::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('assessment.name') !!}</p>
@endsection
